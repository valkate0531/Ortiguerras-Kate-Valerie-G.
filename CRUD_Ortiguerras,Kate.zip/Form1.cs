﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CRUD_Sir_Cabrera
{
    public partial class Form1 : Form
    {
        // Laragon / phpMyAdmin MySQL defaults — edit if your setup differs.
        private readonly string mySqlCon = "server=localhost;user=root;password=;database=bankinformation;";

        public Form1()
        {
            InitializeComponent();

            // Wire events (btnInsert already wired to button1_Click in Designer)
            btnDisplay.Click += (s, e) => LoadUsers();
            btnUpdate.Click += (s, e) => UpdateUser();
            btnDelete.Click += (s, e) => DeleteUser();
            dataGridView1.SelectionChanged += DataGridView1_SelectionChanged;

            // Load rows
            try
            {
                LoadUsers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database initialization error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Designer mapped btnInsert -> this method
        private void button1_Click(object sender, EventArgs e)
        {
            InsertUser();
        }

        private void InsertUser()
        {
            var userId = txtUserId.Text.Trim();
            var userName = txtUserName.Text.Trim();
            var email = txtEmail.Text.Trim();
            var password = txtPassword.Text; // demo only — do not store plaintext in production

            if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(userName))
            {
                MessageBox.Show("User ID and User Name are required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            const string sql = @"INSERT INTO bankinformationdb (Id, name, email, password)
                                 VALUES (@Id, @name, @email, @password);";

            try
            {
                using (var conn = new MySqlConnection(mySqlCon))
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", userId);
                    cmd.Parameters.AddWithValue("@name", userName);
                    cmd.Parameters.AddWithValue("@email", string.IsNullOrEmpty(email) ? (object)DBNull.Value : email);
                    cmd.Parameters.AddWithValue("@password", string.IsNullOrEmpty(password) ? (object)DBNull.Value : password);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Record inserted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadUsers();
                ClearInputs();
            }
            catch (MySqlException mex) when (mex.Number == 1062)
            {
                MessageBox.Show("A record with that User ID already exists.", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insert error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadUsers()
        {
            const string sql = "SELECT id, Id, name, email, password FROM bankinformationdb ORDER BY id DESC;";

            try
            {
                using (var conn = new MySqlConnection(mySqlCon))
                using (var cmd = new MySqlCommand(sql, conn))
                using (var adapter = new MySqlDataAdapter(cmd))
                {
                    var table = new DataTable();
                    adapter.Fill(table);
                    dataGridView1.DataSource = table;
                    dataGridView1.AutoResizeColumns();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateUser()
        {
            var userId = txtUserId.Text.Trim();
            var userName = txtUserName.Text.Trim();
            var email = txtEmail.Text.Trim();
            var password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(userId))
            {
                MessageBox.Show("User ID is required to update a record.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            const string sql = @"UPDATE bankinformationdb
                                 SET name = @name, email = @email, password = @password
                                 WHERE Id = @Id;"; // fixed: use column 'Id' not 'userId'

            try
            {
                using (var conn = new MySqlConnection(mySqlCon))
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@name", userName);
                    cmd.Parameters.AddWithValue("@email", string.IsNullOrEmpty(email) ? (object)DBNull.Value : email);
                    cmd.Parameters.AddWithValue("@password", string.IsNullOrEmpty(password) ? (object)DBNull.Value : password);
                    cmd.Parameters.AddWithValue("@Id", userId);

                    conn.Open();
                    var affected = cmd.ExecuteNonQuery();
                    if (affected > 0)
                    {
                        MessageBox.Show("Record updated.", "Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadUsers();
                        ClearInputs();
                    }
                    else
                    {
                        MessageBox.Show("No record found with that User ID.", "Not found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeleteUser()
        {
            var userId = txtUserId.Text.Trim();
            if (string.IsNullOrWhiteSpace(userId))
            {
                MessageBox.Show("User ID is required to delete a record.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show($"Delete user '{userId}'?", "Confirm delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            const string sql = "DELETE FROM bankinformationdb WHERE Id = @userId;";

            try
            {
                using (var conn = new MySqlConnection(mySqlCon))
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@userId", userId);
                    conn.Open();
                    var affected = cmd.ExecuteNonQuery();
                    if (affected > 0)
                    {
                        MessageBox.Show("Record deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadUsers();
                        ClearInputs();
                    }
                    else
                    {
                        MessageBox.Show("No record found with that User ID.", "Not found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            try
            {
                var drv = dataGridView1.CurrentRow.DataBoundItem as DataRowView;
                if (drv != null)
                {
                    txtUserId.Text = drv.Row["Id"]?.ToString() ?? "";
                    txtUserName.Text = drv.Row["name"]?.ToString() ?? ""; // fixed: column is 'name'
                    txtEmail.Text = drv.Row["email"]?.ToString() ?? "";
                    txtPassword.Text = drv.Row["password"]?.ToString() ?? "";
                }
            }
            catch
            {
                // ignore mapping errors
            }
        }

        private void ClearInputs()
        {
            txtUserId.Clear();
            txtUserName.Clear();
            txtEmail.Clear();
            txtPassword.Clear();
        }

        private void PerformLogin()
        {
            var userId = txtUserId.Text.Trim();
            var password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("User ID and password required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            const string sql = "SELECT name FROM bankinformationdb WHERE Id = @Id AND password = @password LIMIT 1;";

            try
            {
                using (var conn = new MySqlConnection(mySqlCon))
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", userId);
                    cmd.Parameters.AddWithValue("@password", password);
                    conn.Open();
                    var result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        MessageBox.Show($"Welcome, {result}!", "Login successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearInputs();
                    }
                    else
                    {
                        MessageBox.Show("Invalid credentials.", "Login failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Login error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            PerformLogin();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateUser();
        }
    }
}
